package day1;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Radio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
	    
		driver.get("https://testautomationpractice.blogspot.com");
	    driver.manage().window().maximize();
	    //driver.findElement(By.id("sunday")).click();
	    
	    List<WebElement> checkboxes=driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
	    for(WebElement element: checkboxes ) {
	    	element.click();
	    }
	    
	    driver.get("https://the-internet.herokuapp.com/javascript_alerts");
	    
	    //JS alert(only ok button)
	    driver.findElement(By.xpath("//button[text()='Click for JS Alert']"));
	    Alert alert=driver.switchTo().alert();
	    System.out.println(alert.getText());
	    alert.accept();
	    
	    //confirmation alert
	    driver.findElement(By.xpath("//button[text()='Click for JS Confirm']"));
	    Alert confirmalert=driver.switchTo().alert();
	    confirmalert.dismiss();
	    
	    
	    
	    
	    
		

	}

}
