package day1;

public class Datadriven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
