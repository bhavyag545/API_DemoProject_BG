package day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class First {

	public static void main(String[] args) {
		//System.out.println("testing");
		
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://demo.opencart.com/");
		String title= driver.getTitle();
		if(title.equals("Your Store")) {
			System.out.println("Test case Passed");
		}
		String URL=driver.getCurrentUrl();
		if(URL.contains("demo.opencart.com")) {
			System.out.println("Test case Passed");
		}
		driver.close();
		
		

	}

}
