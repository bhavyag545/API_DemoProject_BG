package day1;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waits {

	public static void main(String[] args) throws InterruptedException {

    try{
    	WebDriver driver=new ChromeDriver();
    
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    //WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(3));
    driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    driver.manage().window().maximize();
    //Thread.sleep(3000);
    
   
    //WebElement textusername=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
    //textusername.sendKeys("Bhago");
    
    driver.findElement(By.xpath("//a[text()='OrangeHRM, Inc']")).click();
    Set<String> windowIds=driver.getWindowHandles();
    
    List<String> list=new ArrayList(windowIds);
    String parentId=list.get(0);
    String childId=list.get(1);
    
    //Switch to child window
    driver.switchTo().window(childId);
    
   
	}
	
	catch(Exception e){
		e.printStackTrace();
	}

}
}
